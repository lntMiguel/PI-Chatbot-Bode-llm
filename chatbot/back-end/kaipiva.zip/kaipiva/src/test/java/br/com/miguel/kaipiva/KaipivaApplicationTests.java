package br.com.miguel.kaipiva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaipivaApplicationTests {

	@Test
	void contextLoads() {
	}

}

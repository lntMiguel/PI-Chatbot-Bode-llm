package br.com.miguel.kaipiva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KaipivaApplication {

	public static void main(String[] args) {
		SpringApplication.run(KaipivaApplication.class, args);
	}

}
